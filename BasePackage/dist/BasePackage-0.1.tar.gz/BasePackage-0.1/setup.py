from setuptools import setup

setup(
    name='BasePackage',
    packages=['BasePackage'],
    description='Hello world enterprise edition',
    version='0.1',
    # url='http://github.com/example/linode_example',
    url='https://github.com/primatrix/base_package_test',
    author='primatrix',
    author_email='pritam.parija@gmail.com',
    keywords=['pip','linode','example']
    )